
function Cliente( nome, telefone ) {
    this.nome = nome;
    this.telefone = telefone;
}
