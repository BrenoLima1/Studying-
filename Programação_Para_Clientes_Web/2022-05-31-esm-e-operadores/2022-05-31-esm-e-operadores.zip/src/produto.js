export class Produto {
    id;
    descricao;
    preco;
    constructor( id, descricao, preco ) {
        this.id = id;
        this.descricao = descricao;
        this.preco = preco;
    }
}