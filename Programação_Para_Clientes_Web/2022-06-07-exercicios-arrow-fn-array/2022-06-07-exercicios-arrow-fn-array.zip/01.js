// Exercício 01
export function entreMinMax( arr, min, max ) {
    return arr.filter( e => e >= min && e <= max );
}