class IMC {
    static calcular( pesoEmKg, alturaEmMetros ) {
        return pesoEmKg / ( alturaEmMetros * alturaEmMetros );
    }
}