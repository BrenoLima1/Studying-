window.addEventListener( 'load', aoCarregar );

function aoCarregar() {

    document.getElementById( 'remover' )
        .addEventListener( 'click', remover );

    fetch( 'http://localhost:3000/contatos' )
        .then( resposta => {
            if ( ! resposta.ok ) {
                throw new Error( 'Erro consultando contatos: ' +
                    resposta.status );
            }
            return resposta.json();
        } )
        .then( contatos => desenharContatos( contatos ) )
        .catch( erro => mostrarMensagem( erro.message ) );

}

function desenharContatos( contatos ) {
    const tbody = document.querySelector( 'tbody' );
    for ( const c of contatos ) {
        // Cria as celulas da linha
        const tdId = document.createElement( 'td' );
        tdId.innerText = c.id;
        const tdNome = document.createElement( 'td' );
        tdNome.innerText = c.nome;
        const tdTel = document.createElement( 'td' );
        tdTel.innerText = c.tel;
        // Cria a linha
        const tr = document.createElement( 'tr' );
        // Adiciona as celulas
        tr.append( tdId, tdNome, tdTel );
        // Registra o clique
        tr.addEventListener( 'click', aoClicarNaLinha );
        // Adiciona a linha ao corpo da tabela
        tbody.appendChild( tr );
    }
}


function aoClicarNaLinha( ev ) {
    // Remove a classe das linhas atuais
    const linhasSelecionadas = document.querySelectorAll( 'tr.selecionado' );
    for ( const lin of linhasSelecionadas ) {
        lin.classList.remove( 'selecionado' );
    }
    // Adiciona a classe à linha clicada
    const linha = ev.target.parentNode;
    linha.classList.toggle( 'selecionado' );
}

function mostrarMensagem( mensagem ) {
    document.getElementById( 'mensagem' ).innerText = mensagem;
}


function remover() {
    const linha = document.querySelector( 'tr.selecionado' );
    if ( ! linha ) {
        alert( 'Por favor, selecione.' );
        return;
    }
    const id = linha.firstChild.innerText;

    fetch( `http://localhost:3000/contatos/${id}`, { method: 'DELETE' } )
        .then( resposta => {
            if ( ! resposta.ok ) {
                throw new Error( 'Erro removendo contato: ' +
                    resposta.status );
            }
            // Remove a linha da tabela no HTML
            linha.remove();
        } )
        .catch( erro => mostrarMensagem( erro.message ) );


}