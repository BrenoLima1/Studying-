window.addEventListener('load', aoCarregar);

async function aoCarregar() {

    document.getElementById('remover')
        .addEventListener('click', remover);
        document.getElementById('enviar').addEventListener('click',salvar);
    try {
        const response = await fetch('http://localhost:3000/contatos');
        if (response.status >= 400) {
            throw new Error('Erro ' + response.status);
        }
        const x = await response.json();
        desenharContatos(x);
    } catch (error) {
        mostrarMensagem(error.message);
    }

}

function desenharContatos(contatos) {
    const tbody = document.querySelector('tbody');
    for (const c of contatos) {
        // Cria as celulas da linha
        const tdId = document.createElement('td');
        tdId.innerText = c.id;
        const tdNome = document.createElement('td');
        tdNome.innerText = c.nome;
        const tdTel = document.createElement('td');
        tdTel.innerText = c.tel;
        // Cria a linha
        const tr = document.createElement('tr');
        // Adiciona as celulas
        tr.append(tdId, tdNome, tdTel);
        // Registra o clique
        tr.addEventListener('click', aoClicarNaLinha);
        // Adiciona a linha ao corpo da tabela
        tbody.appendChild(tr);
    }
}


function aoClicarNaLinha(ev) {
    // Remove a classe das linhas atuais
    const linhasSelecionadas = document.querySelectorAll('tr.selecionado');
    for (const lin of linhasSelecionadas) {
        lin.classList.remove('selecionado');
    }
    // Adiciona a classe à linha clicada
    const linha = ev.target.parentNode;
    linha.classList.toggle('selecionado');

    const id = linha.firstChild.innerText;
    const nome = linha.childNodes[1].innerText;
    const telefone = linha.lastChild.innerText;

    preencherFormulario(id, nome, telefone);
}

function atualizarLinhaSelecionada( contato ){
    const linha = document.querySelector('tr.selecionado');
    linha.firstChild.innerText = contato.id;
    linha.childNodes[1].innerText = contato.nome;
    linha.lastChild.innerText = contato.tel;
}

async function salvar(ev) {
    ev.preventDefault();
    const contato = {
        id: document.getElementById('id').value,
        nome: document.getElementById('nome').value,
        tel: document.getElementById('tel').value
    };
    try {
        const response = await fetch(`http://localhost:3000/contatos/${contato.id}`, { method: 'PUT' , headers: {'content-Type' : 'application/json'}, body : JSON.stringify(contato)});
        atualizarLinhaSelecionada(contato);
    } catch (error) {
        mostrarMensagem('Erro ao atualizar usuário ' . error.message);
    }
}

function preencherFormulario(id, nome, telefone) {
    document.getElementById('id').value = id;
    document.getElementById('nome').value = nome;
    document.getElementById('tel').value = telefone;
}

function mostrarMensagem(mensagem) {
    document.getElementById('mensagem').innerText = mensagem;
}


async function remover() {
    const linha = document.querySelector('tr.selecionado');
    const id = linha.firstChild.innerText;
    if (!linha) {
        alert('Por favor, selecione.');
        return;
    }
    try {
        await removerPeloId(id);
        linha.remove();
    } catch (error) {
        mostrarMensagem(error.message);
    }
}

async function removerPeloId(id) {
    try {
        const response = await fetch(`http://localhost:3000/contatos/${id}`, { method: 'DELETE' });
    } catch (error) {
        mostrarMensagem(error.message);
    }
}

